grep analog
support * and ? as special characters as filter

build:
```
make
```

```
cp1251 test:
./tests/test_cp1251.sh
```

use:
```
./sgrep {file} {regexp}
```